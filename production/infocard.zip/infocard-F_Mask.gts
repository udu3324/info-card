G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.2*
G04 #@! TF.CreationDate,2025-07-23T03:13:54-05:00*
G04 #@! TF.ProjectId,infocard,696e666f-6361-4726-942e-6b696361645f,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.2) date 2025-07-23 03:13:54*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.243750X0.456250X-0.243750X0.456250X0.243750X-0.456250X0.243750X-0.456250X-0.243750X0*%
%ADD11R,0.400000X0.280000*%
%ADD12R,0.400000X0.220000*%
%ADD13R,0.220000X0.400000*%
%ADD14RoundRect,0.250000X0.450000X-0.350000X0.450000X0.350000X-0.450000X0.350000X-0.450000X-0.350000X0*%
%ADD15RoundRect,0.250000X-0.475000X0.337500X-0.475000X-0.337500X0.475000X-0.337500X0.475000X0.337500X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,D1*
X173700000Y-101789466D03*
X173700000Y-99914466D03*
G04 #@! TD*
D11*
G04 #@! TO.C,U1*
X173100000Y-108400000D03*
D12*
X173100000Y-108900000D03*
X173100000Y-109400000D03*
D13*
X173700000Y-109500000D03*
D12*
X174300000Y-109400000D03*
X174300000Y-108900000D03*
X174300000Y-108400000D03*
D13*
X173700000Y-108300000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,R1*
X173700000Y-97200000D03*
X173700000Y-95200000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,C1*
X173700000Y-104500000D03*
X173700000Y-106575000D03*
G04 #@! TD*
M02*
